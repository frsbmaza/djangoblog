from django.apps import AppConfig


class FrbblogConfig(AppConfig):
    name = 'frbblog'
